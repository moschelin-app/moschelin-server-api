import datetime

class Config:
    DB_HOST = 'mysqlinstance.cr2sp2mx5gjz.ap-northeast-2.rds.amazonaws.com'
    DB_USER = 'moschelin_db_user'
    DB_PASSWORD = 'moschelin123!@##@!'
    DB_DATABASE = 'moschelin_db'

    SALT = 'moschelin20230815'

    JWT_SECRET_KEY = 'moschelins_jwt'
    JWT_ACCESS_TOKKEN_EXPIRES = False
    PROPAGATE_EXCEPTIONS = True
    
    AWS_ACCESS_KEY_ID = 'AKIAR4D3TFNFOQWCXLMJ'
    AWS_SECRET_ACCESS_KEY = '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'
    JWT_ACCESS_TOKEN_EXPIRES = datetime.timedelta(minutes=720)
    
    S3_BUCKET = 'aws-moschelin-s3'
    S3_Base_URL = f'https://{S3_BUCKET}.s3.amazonaws.com/'
    
    GOOGLE_KEY = 'AIzaSyDPTSlAy52MeqFpGF3V7vcwR663Cxv02eM'
    
    NAVER_CLIENT_KEY = '6tyljnu16e'
    NAVER_SECRET_KEY = '0wWzmbePL6zZGl7LxT8njovFSEHNgNlmRK7IK0nw'

    
    
    
    